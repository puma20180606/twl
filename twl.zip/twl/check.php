<?
echo phpinfo();